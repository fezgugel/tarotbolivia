<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>fezgugel plataforma</title>
</head>

<body>
<div style="background-color:#09F"> 
<table width="100%">
<tr>
<td width="100" align="center"><img src="fezgugel.png" width="100" height="100" "fezgugel.png" /></td>
<td width="130" align="center"></td>
<td width="130" align="center">Inicio</td>
<td width="130" align="center">Nosotros</td>
<td width="130" align="center">Cursos</td>
<td width="130" align="center">Iniciar Sesion</td>
</tr>
</table>
</div>
<div>
<table width="100%">
<tr>
<td width="100%" align="center"><img width="40%" height="40%" src="fezgugel2.png" /></td>
</tr>
</table>
<table>
<tr>
<td width="100%" align="center"><h1>Plataforma Educativa de Cursos Online "Fezgugel"</h1></td>
</table>
<table width="100%">

<td>

</td>
<tr>
<td width="100%" align="center">
<h2>Fezgugel, es un centro de preparación académica preuniversitaria. Actualmente tiene presencia digital mediante la plataforma fezgugel.com en todo el mundo. Varios postulantes que ahora son profesionales exitosos, comenzaron su formación integral en FEZGUGEL y se convencieron de que es posible realizar los sueños al vencer su examen de admisión.</h2>
</td>
<td align="center"></td>
<td align="center"></td>
<td align="center"></td>
<td align="center"></td>
</tr>
</table>
<table width="100%">
<tr>
<td align="center"><img width="100%" height="50%" src="mision.JPG"/></td>
<td align="center"><img width="100%" height="50%" src="vision.JPG" /></td>
<td align="center"><img width="100%" height="50%" src="valores.JPG"/></td>
</tr>
</table>
<table width="100%">
<tr>
<td width="100%" align="center"><img width="85%" height="85%" src="umsa3.JPG"/></td>
</tr>
<tr>
<td width="100%" align="center"><img width="85%" height="85%" src="anapol3.JPG" /></td>
</tr>
<tr>
<td width="100%" align="center"><img width="85%" height="85%" src="colmilav3.JPG"/></td>
</tr>
<tr>
<td width="100%" align="center"><img width="85%" height="85%" src="incos3.JPG" /></td>
</tr>
<tr>
<td width="100%" align="center"><img width="85%" height="85%" src="ESFM3.JPG"/></td>
</tr>
<tr>
<td width="100%" align="center"><img width="250" height="285" src="wasapcurso.jpg"/></td>
</tr>
</table>
</div>
</body>
</html>